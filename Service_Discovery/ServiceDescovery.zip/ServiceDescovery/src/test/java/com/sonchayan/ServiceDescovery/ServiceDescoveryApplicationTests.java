package com.sonchayan.ServiceDescovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDescoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
