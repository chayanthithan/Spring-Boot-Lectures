package com.example.demoResponseAndRequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoResponseAndRequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
