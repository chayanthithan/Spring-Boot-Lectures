package com.example.demoResponseAndRequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoResponseAndRequestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoResponseAndRequestApplication.class, args);
	}

}
