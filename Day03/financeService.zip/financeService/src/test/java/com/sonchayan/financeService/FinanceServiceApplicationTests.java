package com.sonchayan.financeService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
