package com.example.Render.sample.App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RenderSampleAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RenderSampleAppApplication.class, args);
	}

}
